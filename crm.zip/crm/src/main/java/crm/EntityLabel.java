package crm;

import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.awt.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Pattern;

import org.apache.commons.collections4.CollectionUtils;


//XWPF word after 2007 docx
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFTable;

//import Document;
import com.aspose.words.Document;
import com.aspose.words.DocumentBuilder;
import com.aspose.words.Font;
import com.aspose.words.ListCollection;
import com.aspose.words.Node;
import com.aspose.words.NodeCollection;
import com.aspose.words.NodeType;
import com.aspose.words.OoxmlSaveOptions;
import com.aspose.words.Paragraph;
import com.aspose.words.Run;
import com.aspose.words.SaveFormat;
import com.aspose.words.Shape;
import com.aspose.words.Underline;


public class EntityLabel {

	static ArrayList<String> EmbedFormatException =new ArrayList<String>(Arrays.asList("Word.Document.12","Word.Document.8"));
	
	public static void main(String[] args) throws Exception {
		
		
		mainEntityLabel("format/carm.rtf");
		
	}
	public static void mainEntityLabel(String fileName) throws Exception {
		Document doc = new Document(fileName);
		
		int counter = 0;
		String Title = "";
		
		
		NodeCollection paragraphs = doc.getChildNodes(NodeType.PARAGRAPH,true);
		for(Paragraph paragraph :(Iterable<Paragraph>)paragraphs){
			if(paragraph.getAncestor(NodeType.TABLE)==null)
			{
				
			String runText ="";
			
			NodeCollection runs = paragraph.getRuns();
			int boldLast = 0;
			int boldCurrent = 0;
			
			boolean isList =false;
			
			for(Run run :(Iterable<Run>)runs){
				if(run.getFont().getBold()){
					boldLast++;
				}
				if(run.getParentParagraph().isListItem()){
					isList=true;
				}
			}
			if(boldLast>0){
			System.out.println("Last"+boldLast);
			for(Run run :(Iterable<Run>)runs){	 
				if(run.getFont().getBold()){
				boldCurrent++;
				System.out.println("Current"+boldCurrent);	
				if(isList){
					if(boldCurrent==boldLast){
						counter++;
						runText+= run.getText();
						runText = runText.trim().replaceAll("(\\s)+", " ");
						Title = runText;
						run.setText("<header>"+counter+". "+runText+"<header>");
						run.getParentParagraph().getListFormat().removeNumbers();
					}else{
						runText+= run.getText();	
						run.setText("");
					}
					
				}else if(counter>0){
					System.out.println("INSIDE ELSE");
					System.out.println(run.getText());
					if(boldCurrent==boldLast && titleChecker(run)){
						runText+= run.getText();
						runText = runText.trim().replaceAll("(\\s)+", " ");

						System.out.println("++++++++++++++");
						System.out.println(run.getFont().getName().toString());
						run.setText("<header>"+counter+". "+Title+" -> "+runText+"<header>");
					}else if(titleChecker(run)){
						
						runText+= run.getText();		
						run.setText("");
					}					
				}
				
			}
		}
		}
				
			System.out.println(runText);	
			
			}
		}
		
		doc.save(fileName);
		
	}
	
	public static boolean titleChecker(Run run){
		boolean isTitle = true;
		if(run.getFont().getColor().equals(Color.BLUE)){
			isTitle = false;
			System.out.println("Not black - blue");
		}
		
		if(run.getFont().getColor().equals(Color.RED)){
			isTitle = false;
			System.out.println("Not black -red");
		}
		if(!(run.getText().trim().length()>0)){
			isTitle = false;
			System.out.println("All space");
		}	
		if(run.getFont().getItalic()){
			isTitle = false;
			System.out.println("Italic");
		}
		if(run.getFont().getName().toString().equals("Wingdings")){
			isTitle = false;
			System.out.println("Symbol");
		}
		
		return isTitle;
	}
	public static void removeNoiseEmbedFile(String filename) throws Exception{
		
		try{
		Document doc = new Document(filename);
		
		NodeCollection shapes =doc.getChildNodes(NodeType.SHAPE, true);
		for(Shape shape:(Iterable<Shape>) shapes){
			
			if (shape.getOleFormat() != null){
				if(!EmbedFormatException.contains(shape.getOleFormat().getProgId())){
				doc.getChildNodes(NodeType.SHAPE, true).remove(shape);
				}
			}else{
				doc.getChildNodes(NodeType.SHAPE, true).remove(shape);
			}
			
		}
		
		doc.save(filename);
		System.out.println("Noise embedded file is removed");
		}catch (FileNotFoundException e) {
			System.out.println(e);
		}
		
	}
	
	public static void nodetypeRun(String fileName) throws Exception {
		Document doc = new Document("fileName");
		
		int counter = 0;
		String Title = "";
		
		
		NodeCollection paragraphs = doc.getChildNodes(NodeType.PARAGRAPH,true);
		for(Paragraph paragraph :(Iterable<Paragraph>)paragraphs){
			String runText ="";
			
			NodeCollection runs = paragraph.getRuns();
			int boldLast = 0;
			int boldCurrent = 0;
			
			boolean isList =false;
			
			for(Run run :(Iterable<Run>)runs){
				if(run.getFont().getBold()){
					boldLast++;
				}
				if(run.getParentParagraph().isListItem()){
					isList=true;
				}
			}
			if(boldLast>0){
			System.out.println("Last"+boldLast);
			for(Run run :(Iterable<Run>)runs){	 
				if(run.getFont().getBold()){
				boldCurrent++;
				System.out.println("Current"+boldCurrent);	
				if(isList){
					if(boldCurrent==boldLast){
						counter++;
						runText+= run.getText();
						runText = runText.trim();
						Title = runText;
						run.setText("<header>"+counter+". "+runText+"<header>");
						run.getParentParagraph().getListFormat().removeNumbers();
					}else{
						runText+= run.getText();	
						run.setText("");
					}
					
				}else if(counter>0){
					System.out.println("INSIDE ELSE");
					System.out.println(run.getText());
					if(boldCurrent==boldLast){
						runText+= run.getText();
						runText = runText.trim();
						run.setText("<header>"+counter+". "+Title+" -> "+runText+"<header>");
					}else{
						runText+= run.getText();		
						run.setText("");
					}					
				}
				
			}
		}
		}
				
			System.out.println(runText);	
		}
		
		doc.save("fileName");
		
	}
	


}
