package crm;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.aspose.words.Cell;
//import Document;
import com.aspose.words.Document;
import com.aspose.words.NodeType;
import com.aspose.words.OoxmlSaveOptions;
import com.aspose.words.Row;
import com.aspose.words.SaveFormat;
import com.aspose.words.Table;

public class AsposeExtractTable {

	public static void main(String[] args) throws Exception {

		String fileName = "format/Doc1.docx";
		Document doc = new Document(fileName);

	ArrayList<String> rowEx = new ArrayList<String>(Arrays.asList("jo"));
	ArrayList<String> rowTarget = new ArrayList<String>();
	List <String> rowArray = new ArrayList();
	Table table =(Table)doc.getChild(NodeType.TABLE, 0,true);
	

	for(Row r:table.getRows()){
		String rowText ="";	
		for(Cell c:r.getCells()){
				rowText+= c.getText();
		}
		rowArray.add(rowText);		
	}
	
	for(String test:rowArray){
		for(String Ex: rowEx)
			if(test.contains(Ex)){
				rowTarget.add(test);

				System.out.println(test);
				break;
			}
	}
	

	System.out.println(rowTarget.toString());
	
	
	
	}
}
