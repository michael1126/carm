package crm;

import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.awt.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Pattern;

import org.apache.commons.collections4.CollectionUtils;


//XWPF word after 2007 docx
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;

//import Document;
import com.aspose.words.Document;
import com.aspose.words.DocumentBuilder;
import com.aspose.words.Font;
import com.aspose.words.ListCollection;
import com.aspose.words.Node;
import com.aspose.words.NodeCollection;
import com.aspose.words.NodeType;
import com.aspose.words.OoxmlSaveOptions;
import com.aspose.words.Paragraph;
import com.aspose.words.Run;
import com.aspose.words.SaveFormat;
import com.aspose.words.Shape;
import com.aspose.words.Underline;
import com.google.common.io.Files;


public class tmp {

	public static void main(String[] args) throws Exception {
		String fileName = "format/carm.rtf";
		File testFile = new File(fileName);		
		
		boolean nextCell = false;
		
		
		XWPFDocument XWPFdoc = new XWPFDocument(new FileInputStream(testFile));
		List <XWPFTable> table = XWPFdoc.getTables();
		for (XWPFTable xwpfTable : table) {
			List<XWPFTableRow> row = xwpfTable.getRows();
			for (XWPFTableRow xwpfTableRow : row) {
				List<XWPFTableCell> cells = xwpfTableRow.getTableCells();
				for(XWPFTableCell cell : cells){
					if(nextCell==true){
						System.out.println("Found:"+cell.getText());
						nextCell = false;
					}
					if(cell.getText().contains("TR NAME")){
						nextCell = true;
					}
				}
			
			}
		}
		
	}
	
	
	
	 public static void insertTableRowToText(ArrayList<String> rowException,String filePath) throws Exception {
			
	    	ArrayList<String> rowEx = rowException;
			String tableTarget ="";
			XWPFDocument XWPFdoc = new XWPFDocument(new FileInputStream(filePath));
			List <String> rowArray = new ArrayList<String>();
			List <XWPFTable> table = XWPFdoc.getTables();
			for (XWPFTable xwpfTable : table) {
				List<XWPFTableRow> row = xwpfTable.getRows();
				for (XWPFTableRow xwpfTableRow : row) {
					String rowText ="";
					List<XWPFTableCell> cell = xwpfTableRow.getTableCells();
					for (XWPFTableCell xwpfTableCell : cell) {
						if(xwpfTableCell!=null)
						{
							rowText+= xwpfTableCell.getText()+" ";
						}
					}
					rowArray.add(rowText);
				}
			}
			XWPFdoc.close();
			
			for(String test:rowArray){
				for(String Ex: rowEx)
					if(test.contains(Ex)){
						tableTarget+="<"+Ex+">";
						tableTarget+= test;
						tableTarget+="<"+Ex+">";
						tableTarget+="\n";
						break;
					}
			}
			
	    	if(!tableTarget.equals("")){
				Document doc = new Document(filePath);		
				DocumentBuilder builder = new DocumentBuilder(doc);
				Font font = builder.getFont();
				font.setSize(10);
				font.setBold(false);
				font.setName("Calibri");
				font.setColor(Color.black);
				builder.write(tableTarget);
				doc.save(filePath);
			
				
			
				System.out.println("Exception row is extracted");
	
				System.out.println("["+tableTarget+"]");
	    	}
		}
	
	 
}
