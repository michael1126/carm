package crm;
import java.io.File;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import org.apache.tika.cli.TikaCLI;
import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.Parser;
import org.apache.tika.parser.txt.TXTParser;
import org.apache.tika.sax.BodyContentHandler;
import org.xml.sax.SAXException;

import org.apache.tika.parser.AutoDetectParser;
import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

public class ReadContent {
	static ArrayList<String> blackList = new ArrayList<String>(Arrays.asList("xlsx"));
	static ArrayList<String> imageList = new ArrayList<String>(Arrays.asList("emf","wmf","jpg","jpeg","png"));
	static ArrayList<String> vbaList = new ArrayList<String>(Arrays.asList("doc","docx","rtf"));
	private static String wordPath ="C:\\Program Files (x86)\\Microsoft Office\\root\\Office16\\WINWORD.EXE ";
	
	
	public static void main(String[] args) throws Exception {

		String sourcePath ="format/sample.rtf";
		File sourceRTF = new File(sourcePath);		  
		
		String fileNameExtension = sourceRTF.getName();			//sample.rtf
		String filePath = sourceRTF.getParentFile().getPath();	
		String fileName = fileNameExtension.substring(0,fileNameExtension.lastIndexOf('.'));	//sample
		String fileLoc = filePath+'/'+fileName;
		
		
		//Start of recursion
		recursiveExtract(sourceRTF);
		
		//Remove table content of source file
		String contentRTF = extract(sourcePath);
		File tmpRTF = new File(fileLoc+'/'+fileNameExtension);
		tmpRTF.createNewFile();
		FileWriter fw = new FileWriter(tmpRTF,true); //the true will append the new data
		fw.write(contentRTF);//appends the string to the file
		fw.close();
		
		System.out.println("Finish");
	}
	
	public static String extract(String filepath) throws IOException,TikaException,SAXException, InvalidFormatException
    { 

		  File testRTF = new File(filepath);		  
		  FileInputStream stream = new FileInputStream(testRTF);
		  BodyContentHandler handler = new BodyContentHandler(-1);
		  Metadata metadata = new Metadata();
		  ParseContext pcontext = new ParseContext();
		  
		  TXTParser parser = new TXTParser(); 
		 
		  parser.parse(stream, handler, metadata,pcontext);
		  
		String contentRTF = handler.toString();

		int ltrrow = 0;
		int row1 = 0;
		int row2 = 0;
		int length1 =6;
		int length2 =4;
				
		while(true){
			if(row1==-1 && row2==-1){
				break;
			}
			
			ltrrow = ltrrowStart(contentRTF);
			row1 = indexPattern(contentRTF,"row \r");
			row2 = indexPattern(contentRTF,"row }");
			if(row1!=-1 && row2!=-1){
				if(row1<row2)
					contentRTF = deleteTable(contentRTF,ltrrow,row1,length1);	
				if(row2<row1)
					contentRTF = deleteTable(contentRTF,ltrrow,row2,length2);
			}else if(row1==-1 &&row2!=-1){
				contentRTF = deleteTable(contentRTF,ltrrow,row2,length2);	
			}else if(row2==-1 &&row1!=-1){
				contentRTF = deleteTable(contentRTF,ltrrow,row1,length1);	
			}
			System.out.println(String.format("row1: %d",row1));
			System.out.println(String.format("row2: %d",row2));
			
			
		}
	
		return contentRTF;
    }
	
	public static String deleteSubstring(String text,String subString,String endString){
		
		int start = text.indexOf(subString);
		int end= text.indexOf(endString,start);
		int dest_index = 0;
		char[] result = new char[text.length()];

	    for(int i = 0; i< text.length() - 1; i++)
	    	if(i<start || i>=end)
	    		result[dest_index++] = text.charAt(i);
		return new String(result,0,dest_index+1);
	}
	
	public static int indexPattern(String text,String _pattern){
        Pattern pattern = Pattern.compile(_pattern);		

        Matcher matcher = pattern.matcher(text);
	    return matcher.find() ? matcher.start() : -1;
	}
	
	public static int ltrrowStart(String text){
		int target = -1;
		int firstT = text.indexOf("\\ltrrow");

		for(int t = firstT;t>0;t--){
			if(text.charAt(t)=='{'){
				target = t;
				return target;
			}
		}
		
		return target;
	}
	public static String deleteTable(String text,int s,int e,int length){
		int start = s;
		int end= e+length;
		int dest_index = 0;
		char[] result = new char[text.length()];

	    for(int i = 0; i< text.length() - 1; i++)
	    	if(i<start || i>end)
	    		result[dest_index++] = text.charAt(i);
		return new String(result,0,dest_index+1);
	}
	
	public static String getExtension(String filename) {
        if (filename == null) {
            return null;
        }
        int extensionPos = filename.lastIndexOf('.');
        
        return filename.substring(extensionPos+1,filename.length());
        
    }
	
	public static File newFile(File f, String newName,String extension) {
	
		  return new File(f.getParent() + "/" + newName + "." + extension);
		}
	
	public static File changeExtension(File f, String newExtension) {
		  int i = f.getName().lastIndexOf('.');
		  String name = f.getName().substring(0,i);
		  return new File(f.getParent() + "/" + name + newExtension);
		}

	public static void recursiveExtract(File initFile) throws IOException, SAXException, TikaException, InterruptedException{
		String filePath = initFile.getPath().substring(0,initFile.getPath().lastIndexOf("\\")+1);
		String fileName = initFile.getName().substring(0,initFile.getName().lastIndexOf('.'));
		String fileLoc = filePath+fileName;
		
		String input = initFile.getPath();
		//create an empty file to store modified file and embedded files
		//fileName as the folder name
		File dir = new File(fileLoc);	
		dir.mkdir();
		
		//extract all embedded doc in initFile
		try{
	        String[] arguments = new String[]{"-z", "--extract-dir="+fileLoc, input};
	        System.out.println("Using TIKA CLI to dedect embedded Files. Target Directory: "+ fileLoc);
	        TikaCLI.main(arguments);
	        
	    }
	    catch(Exception e){
	    	System.out.println("Exception in saveEmbedds, during search in File: " + input + "\r\nDetails: " + e);
	    }
		
		//get the imageName
		ArrayList<String> imageName = new ArrayList<String>(); 
		File [] directoryListing = dir.listFiles();
		Arrays.sort(directoryListing, LastModifiedFileComparator.LASTMODIFIED_COMPARATOR);	
		if(directoryListing!=null){
			for(File child :directoryListing){
				//get doc to rtf
				String extension = child.getName().substring(child.getName().lastIndexOf('.')+1,child.getName().length());
				//before delete useless file,
				//extract the name and rename file
				if(extension.equals("emf")){
					Parser parser = new AutoDetectParser();
					BodyContentHandler handler = new BodyContentHandler();
					Metadata metadata = new Metadata();   //empty metadata object 
					FileInputStream inputstream = new FileInputStream(child);
					ParseContext context = new ParseContext();
					parser.parse(inputstream, handler, metadata, context);

					// now this metadata object contains the extracted metadata of the given file.
					String childHandler = handler.toString();
					String childName = childHandler.substring(0,childHandler.lastIndexOf('.'));
					imageName.add(childName.trim().replaceAll("\\s","_"));
					inputstream.close();
				}							
			}
		}
		
		//delete image
		if(directoryListing!=null){
			for(File child :directoryListing){
				String extension = child.getName().substring(child.getName().lastIndexOf('.')+1,child.getName().length());
				if(imageList.contains(extension)){
					File file = new File(fileLoc +'/'+ child.getName());
					boolean isDelete = file.delete();
					System.out.println(fileLoc +'/'+ child.getName()+" is deleted from directory");
					System.out.println(isDelete);
				}
			}
		}
		for(String ss:imageName){
			System.out.println(ss);
		}
		
		//rename file
		//the file order of second layer
		directoryListing = dir.listFiles();
		Arrays.sort(directoryListing, LastModifiedFileComparator.LASTMODIFIED_COMPARATOR);		
		if(directoryListing!=null){
			int childIndex=0;
			for(File child :directoryListing){
				String extension = child.getName().substring(child.getName().lastIndexOf('.')+1,child.getName().length());
				if(!imageList.contains(extension)){
				System.out.println("File index: "+childIndex);
				File newChild = newFile(child,imageName.get(childIndex),extension);		
				System.out.println(child.getName()+" is renamed to "+ newChild.getName());
				boolean isSuccess = child.renameTo(newChild);
				System.out.println(isSuccess);
				childIndex++;
				}
			}
		}
		
		//delete blacklist doc
		directoryListing = dir.listFiles();
		if(directoryListing!=null){
			for(File child :directoryListing){
				String extension = child.getName().substring(child.getName().lastIndexOf('.')+1,child.getName().length());
				if(blackList.contains(extension)){
					File file = new File(fileLoc +'/'+ child.getName());
					file.delete();
					System.out.println(fileLoc +'/'+ child.getName()+" is deleted from directory");
				}			
			}
		}
		
		//remove rtf table
		directoryListing = dir.listFiles();
		if(directoryListing!=null){
			for(File child :directoryListing){
				//get doc to rtf
				String extension = child.getName().substring(child.getName().lastIndexOf('.')+1,child.getName().length());

				if(blackList.contains(extension)){
					File file = new File(fileLoc +'\\'+ child.getName());
					file.delete();
					System.out.println(fileLoc +'\\'+ child.getName()+" deleted from directory");
					continue;
				}
				if(vbaList.contains(extension)){
					
					Runtime rt = Runtime.getRuntime();
					String childPath = child.getPath().toString().replaceAll("\\\\","\\\\\\\\");
					rt.exec(wordPath+ childPath+" /w /mremoveTable");
					
					System.out.println("Deleting table from "+ child.getPath());
					
				}
				
			}
		}
		
		//remove folder if empty
		directoryListing = dir.listFiles();
		if(directoryListing.length == 0){
			dir.delete();
			System.out.println("Deleting empty folder");
		}
		
		//recursion
		directoryListing = dir.listFiles();
		if(directoryListing!=null){
			for(File child :directoryListing){
				String extension = child.getName().substring(child.getName().lastIndexOf('.')+1,child.getName().length());
				if(vbaList.contains(extension)){
				//loop
				recursiveExtract(child);	
				
				}
				
			}
		}		
	}

}
