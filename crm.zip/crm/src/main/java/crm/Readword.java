package crm;
import java.io.File;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.text.html.HTMLDocument.Iterator;
import javax.swing.text.rtf.RTFEditorKit;

import org.apache.tika.Tika;
import org.apache.tika.cli.TikaCLI;
import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.metadata.TikaCoreProperties;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.html.HtmlParser;
import org.apache.tika.parser.rtf.RTFParser;
import org.apache.tika.parser.txt.TXTParser;
import org.apache.tika.sax.BodyContentHandler;
import org.apache.tika.sax.ContentHandlerDecorator;
import org.apache.tika.sax.TaggedContentHandler;
import org.apache.tika.sax.ToXMLContentHandler;
import org.xml.sax.SAXException;

import com.rtfparserkit.converter.text.StringTextConverter;
import com.rtfparserkit.parser.IRtfParser;
import com.rtfparserkit.parser.IRtfSource;
import com.rtfparserkit.parser.RtfStreamSource;
import com.rtfparserkit.parser.standard.StandardRtfParser;

import org.apache.tika.parser.AutoDetectParser;
import org.apache.commons.io.FileUtils;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.extractor.WordExtractor;
import org.apache.poi.hwpf.model.*;
import org.apache.poi.hwpf.usermodel.*;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
 
import java.util.List;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;

import java.util.ArrayList; 

public class Readword {
	
	static ArrayList<String> blackList = new ArrayList<String>(Arrays.asList("emf","wmf","xlsx"));
	
	public static void main(String[] args) throws Exception {
		
		
		
		String sourcePath ="format/carm.rtf";
		File sourceRTF = new File("format/carm.rtf");		  
		
		String fileNameExtension = sourceRTF.getName();			//sample.rtf
		String filePath = sourceRTF.getParentFile().getPath();	
		String fileName = fileNameExtension.substring(0,fileNameExtension.lastIndexOf('.'));	//sample
		String fileLoc = filePath+'/'+fileName;
		
		//create an empty file to store modified file and embedded files
		//fileName as the folder name
		File dir = new File(fileLoc);	
		dir.mkdir();
		//save embedded file to fileLoc
		saveEmbedds(sourcePath,fileLoc);

		//problem-tika extract rtf as doc
		//change doc to rtf
		//remove unwanted document
		File [] directoryListing = dir.listFiles();
		if(directoryListing!=null){
			for(File child :directoryListing){
				//get doc to rtf
				String extension = child.getName().substring(child.getName().lastIndexOf('.')+1,child.getName().length());

				if(blackList.contains(extension)){
					File file = new File(fileLoc +'/'+ child.getName());
					file.delete();
					System.out.println(fileLoc +'/'+ child.getName()+" deleted from directory");
					
				}
				if(extension.equals("doc")){
					File newChild = changeExtension(child,".rtf");
					child.renameTo(newChild);
				}
				
				
			}
		}
		
		//recursive loop other layers 
		directoryListing = dir.listFiles();
		if(directoryListing!=null){
			for(File child :directoryListing){
				String extension = child.getName().substring(child.getName().lastIndexOf('.')+1,child.getName().length());
				if(extension.equals("rtf")){
				//loop
				recursiveExtract(child);	
				
				}
			
			}
		}
		
		//Remove table content of source file
		String contentRTF = extract(sourcePath);
		File tmpRTF = new File(fileLoc+'/'+fileNameExtension);
		tmpRTF.createNewFile();
		FileWriter fw = new FileWriter(tmpRTF,true); //the true will append the new data
		fw.write(contentRTF);//appends the string to the file
		fw.close();
		
		System.out.println("Finish");
	}
	
	public static String extract(String filepath) throws IOException,TikaException,SAXException, InvalidFormatException
    { 

		  File testRTF = new File(filepath);		  
		  FileInputStream stream = new FileInputStream(testRTF);
		  BodyContentHandler handler = new BodyContentHandler(-1);
		  Metadata metadata = new Metadata();
		  ParseContext pcontext = new ParseContext();
		  
		  TXTParser parser = new TXTParser(); 
		 
		  parser.parse(stream, handler, metadata,pcontext);
		  
		String contentRTF = handler.toString();

		int ltrrow = 0;
		int row1 = 0;
		int row2 = 0;
		int length1 =6;
		int length2 =4;
				
		while(true){
			if(row1==-1 && row2==-1){
				break;
			}
			
			ltrrow = ltrrowStart(contentRTF);
			row1 = indexPattern(contentRTF,"row \r");
			row2 = indexPattern(contentRTF,"row }");
			if(row1!=-1 && row2!=-1){
				if(row1<row2)
					contentRTF = deleteTable(contentRTF,ltrrow,row1,length1);	
				if(row2<row1)
					contentRTF = deleteTable(contentRTF,ltrrow,row2,length2);
			}else if(row1==-1 &&row2!=-1){
				contentRTF = deleteTable(contentRTF,ltrrow,row2,length2);	
			}else if(row2==-1 &&row1!=-1){
				contentRTF = deleteTable(contentRTF,ltrrow,row1,length1);	
			}
			System.out.println(String.format("row1: %d",row1));
			System.out.println(String.format("row2: %d",row2));
			
			
		}
	
		return contentRTF;
    }
	
	public static String deleteSubstring(String text,String subString,String endString){
		
		int start = text.indexOf(subString);
		int end= text.indexOf(endString,start);
		int dest_index = 0;
		char[] result = new char[text.length()];

	    for(int i = 0; i< text.length() - 1; i++)
	    	if(i<start || i>=end)
	    		result[dest_index++] = text.charAt(i);
		return new String(result,0,dest_index+1);
	}
	
	public static int indexPattern(String text,String _pattern){
        Pattern pattern = Pattern.compile(_pattern);		

        Matcher matcher = pattern.matcher(text);
	    return matcher.find() ? matcher.start() : -1;
	}
	
	public static int ltrrowStart(String text){
		int target = -1;
		int firstT = text.indexOf("\\ltrrow");
//		System.out.println(firstT);
//		for(int i=21583;i<=21650;i++)
//			System.out.print(text.charAt(i));

		for(int t = firstT;t>0;t--){
			if(text.charAt(t)=='{'){
				target = t;
				return target;
			}
		}
		
		return target;
	}
	public static String deleteTable(String text,int s,int e,int length){
		int start = s;
		int end= e+length;
		int dest_index = 0;
		char[] result = new char[text.length()];

	    for(int i = 0; i< text.length() - 1; i++)
	    	if(i<start || i>end)
	    		result[dest_index++] = text.charAt(i);
		return new String(result,0,dest_index+1);
	}
	
	public static void saveEmbedds(String inputfile, String outputfile) throws Exception{
		try{
	        String[] arguments = new String[]{"-z", "--extract-dir=" +outputfile, inputfile};
	        System.out.println("Using TIKA CLI to dedect embedded Files. Target Directory: "+ outputfile);
	        TikaCLI.main(arguments);
	    }
	    catch(Exception e){
	    	System.out.println("Exception in saveEmbedds, during search in File: " + inputfile + "\r\nDetails: " + e);
	    }

	}
	
	public static File changeExtension(File f, String newExtension) {
		  int i = f.getName().lastIndexOf('.');
		  String name = f.getName().substring(0,i);
		  return new File(f.getParent() + "/" + name + newExtension);
		}
	
	public static void recursiveExtract(File initFile){
		String filePath = initFile.getPath().substring(0,initFile.getPath().lastIndexOf("\\")+1);
		String fileName = initFile.getName().substring(0,initFile.getName().lastIndexOf('.'));
		String fileLoc = filePath+fileName;
		
		String input = initFile.getPath();
		//create an empty file to store modified file and embedded files
		//fileName as the folder name
		File dir = new File(fileLoc);	
		dir.mkdir();
		
		//create new folder
		try{
	        String[] arguments = new String[]{"-z", "--extract-dir="+fileLoc, input};
	        System.out.println("Using TIKA CLI to dedect embedded Files. Target Directory: "+ fileLoc);
	        TikaCLI.main(arguments);
	    }
	    catch(Exception e){
	    	System.out.println("Exception in saveEmbedds, during search in File: " + input + "\r\nDetails: " + e);
	    }
		
		//remove rtf table
		File [] directoryListing = dir.listFiles();
		if(directoryListing!=null){
			for(File child :directoryListing){
				//get doc to rtf
				String extension = child.getName().substring(child.getName().lastIndexOf('.')+1,child.getName().length());

				if(blackList.contains(extension)){
					File file = new File(fileLoc +'/'+ child.getName());
					file.delete();
					System.out.println(fileLoc +'/'+ child.getName()+" deleted from directory");
					
				}
				if(extension.equals("doc")){
					File newChild = changeExtension(child,".rtf");
					child.renameTo(newChild);
				}
				
			}
		}
		
		//if have rtf file 
		//recursion
		directoryListing = dir.listFiles();
		if(directoryListing!=null){
			for(File child :directoryListing){
				String extension = child.getName().substring(child.getName().lastIndexOf('.')+1,child.getName().length());
				if(extension.equals("rtf")){
				//loop
				recursiveExtract(child);	
				
				}
			
			}
		}
		
		
		
	}

}
