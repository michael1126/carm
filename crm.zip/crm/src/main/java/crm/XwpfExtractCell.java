package crm;

import java.awt.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;

import com.aspose.words.Document;
import com.aspose.words.DocumentBuilder;
import com.aspose.words.Font;
//get row
public class XwpfExtractCell {

	
	public static void main(String[] args) throws Exception {

		ArrayList<String> rowException = new ArrayList<String>(Arrays.asList("jo","OIO"));
		String fileName = "format/Doc4.docx";
		insertTableRowToText(rowException,fileName);
	
	}
	public static void insertTableRowToText(ArrayList<String> rowException,String filePath) throws Exception {
		ArrayList<String> rowEx = rowException;
		String tableTarget ="";
		XWPFDocument XWPFdoc = new XWPFDocument(new FileInputStream(filePath));
		List <String> rowArray = new ArrayList();
		List <XWPFTable> table = XWPFdoc.getTables();
		for (XWPFTable xwpfTable : table) {
			List<XWPFTableRow> row = xwpfTable.getRows();
			for (XWPFTableRow xwpfTableRow : row) {
				String rowText ="";
				List<XWPFTableCell> cell = xwpfTableRow.getTableCells();
				for (XWPFTableCell xwpfTableCell : cell) {
					if(xwpfTableCell!=null)
					{
						rowText+= xwpfTableCell.getText();
//						System.out.println(xwpfTableCell.getText());
					}
				}
				rowArray.add(rowText);
			}
		}
		
		for(String test:rowArray){
			for(String Ex: rowEx)
				if(test.contains(Ex)){
					tableTarget+= test+'\n';
					break;
				}
		}
		
		Document doc = new Document(filePath);		
		DocumentBuilder builder = new DocumentBuilder(doc);
		Font font = builder.getFont();
		font.setSize(16);
		font.setBold(true);
		font.setName("Calibri");
		font.setColor(Color.blue);
		builder.write(tableTarget);
		doc.save(filePath);
		
	
		System.out.print("Exception row is extracted");
		
	}

}
